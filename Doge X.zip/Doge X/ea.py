import pymem
import re
import time
import ctypes